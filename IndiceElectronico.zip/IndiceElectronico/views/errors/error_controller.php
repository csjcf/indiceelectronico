<!DOCTYPE html>
<html>
<body>
  <a href="http://190.217.24.24/recepcionmemoriales/"><img src="../img/error.png" style="margin-left: calc((100% - 1383px)/2); margin-top: 2%;"></a>
</body>
</html>
