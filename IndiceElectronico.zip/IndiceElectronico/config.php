<?php
$config = Config::singleton();

$config->set('controllersFolder', 'controllers/');
$config->set('modelsFolder', 'models/');
$config->set('viewsFolder', 'views/');

$config->set('dbhost', 'localhost');
$config->set('dbname', 'centro_servicios2');
$config->set('dbuser', 'cs');
$config->set('dbpass', 'Servicios2020**');

define('titulo',' - Rama Judicial -');
define('rutabase','/login/');


?>
